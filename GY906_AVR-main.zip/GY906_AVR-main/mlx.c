/*******************************************************



Chip type               : ATmega32A
AVR Core Clock frequency: 8.000000 MHz

*******************************************************/

#include <mega32a.h>
#include <lcd.h>
#include <delay.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <i2c.h>
#asm
.equ __lcd_port=0x18     ///B
#endasm




//+++++++++++++++++++++++++++++++++++++
char str[17];

long low,high,j;

float t;
//+++++++++++++++++++++++++++++++++++++


void main(void)
{
lcd_init(16);
DDRC=0xff;

i2c_init();






lcd_clear();
while (1)
      {
       
        i2c_start();
        
        i2c_write(0xB4);
       
        i2c_write(0x07);
        
        i2c_start();
        
        i2c_write(0xB5);

        low  =  i2c_read(1);
        high =  i2c_read(1);
        j    =  i2c_read(0); 
       
        i2c_stop();     
        
       t=((((( high &0x007F)<<8)+ low)*0.02)-0.01);
        
       t= t - 273.15;
       
        
        itoa(t,str);
        
        lcd_gotoxy(0,0); 
       
        lcd_puts("TEMP:");
        
        
        
        lcd_gotoxy(5,0); 
       
        lcd_puts(str); 
       
        delay_ms(300);
      }
}
